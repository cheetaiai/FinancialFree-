# FinancialFree Android Native App Project
This repository project allows compiling FinancialFree directly into an official signed APK or Google Play Store Bundle (.aab).

## How to Build:
1. Open this folder in Android Studio.
2. Click Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The generated release APK will be located in app/build/outputs/apk/release/.
